# Kerin : Un nouveau package pour créer des réseaux de neurones

Semblable à Tensorflow